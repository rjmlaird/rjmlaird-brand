# Brand design tokens — rjmlaird.co.uk / rjmlaird-dev

Source: uploaded `global.css` (design tokens in `:root`, lines 14–65). The CSS is the authority; the PowerPoint mappings below are presentation adaptations.

## Colour tokens

| CSS token | Value | PowerPoint role |
|---|---|---|
| `--ink` | `#0B0F1A` | Primary slide background |
| `--ink2` | `#0F1520` | Alternate / section background |
| `--card` | `#141B29` | Content panels and chart/table surfaces |
| `--lift` | `#1A2236` | Raised surface / table alternation |
| `--w` | `#EDEAE3` | Primary text |
| `--mb` | `#9AA4B8` | Secondary text and explanatory copy |
| `--m` | `#8A98B2` | Muted text; use cautiously for small text |
| `--teal` | `#00C2A8` | Primary accent, key labels and action cues |
| `--amber` | `#F5A623` | Secondary emphasis and technical metadata |
| `--violet` | `#A78BFA` | Alternate category / comparison |
| `--coral` | `#FF8080` | Warning / risk category |
| `--green` | `#4ADE80` | Positive outcome / completion category |
| `--sky` | `#38BDF8` | Supporting category |
| `--focus` | `#7FE6D4` | Focus / accessibility reference |
| `--bd` | `rgba(255,255,255,.11)` | Subtle separators; approximated as `#303846` in PPT |
| `--bm` | `rgba(255,255,255,.2)` | Stronger separator; use a light neutral line |
| `--td`, `--ad`, `--vd`, `--cd`, `--gd`, `--sd` | translucent accent fills | PPT uses solid dark surfaces with accent borders where alpha is not portable |

## Typography

| CSS token | Value | PowerPoint use |
|---|---|---|
| `--font-display` | `Space Grotesk`, system sans fallback | Titles, section headings, labels |
| `--font-body` | `Inter`, system sans fallback | Body text, captions and tables |
| `--font-mono` | `JetBrains Mono`, monospace fallbacks | Dates, slide numbers, IDs, technical metadata |

Font availability is not guaranteed on recipients' devices. Install the fonts or expect Office to substitute. This deck uses theme-consistent font names but does not embed fonts.

## Layout tokens and interpretation

- `--content-max: 1320px`: mapped to a generous widescreen content area.
- `--gutter-min: clamp(1.25rem, 5vw, 2.5rem)`: interpreted as roughly 0.7–0.8 in safe margins on a 13.333 × 7.5 in slide.
- `--section-y: clamp(3rem, 6vw, 5rem)`: translated to generous vertical spacing, not literal CSS pixels.
- `--radius: 6px`: PowerPoint uses square-corner panels and simple outlines by default; native shape rounding is restrained.
- Dark theme is explicit (`color-scheme: dark`); no separate light theme is defined in the source CSS.

## Presentation-specific decisions

1. Slide size is 16:9 widescreen, 13.333 × 7.5 inches, per the brief.
2. Most content slides use a 0.72–0.82 in horizontal safe margin.
3. Font sizes are adapted to presentation distance; the website's rem values are not converted literally.
4. CSS alpha colours are approximated with solid dark surfaces and visible accent borders because PowerPoint transparency can render differently across versions.
5. The orbital title-slide motif is editable PowerPoint vector geometry, not a supplied brand asset. It is a restrained interpretation of the site's orbital/space subject matter.
6. `#303846` is a presentation-only line approximation of the CSS `--bd` translucent white border over dark backgrounds.
7. Example chart data and KPI values are explicitly illustrative placeholders, not factual claims.
