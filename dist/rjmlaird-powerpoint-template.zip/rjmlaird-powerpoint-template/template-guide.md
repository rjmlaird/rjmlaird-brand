# Template guide — rjmlaird.co.uk

## Design principle
Use the website's dark, technical and editorial character: near-black navy surfaces, warm off-white text, teal as the primary accent, restrained secondary colours, and clean typography. Prioritise evidence, hierarchy and whitespace over decoration.

## Choosing a layout
1. **Title** — state the subject and why it matters.
2. **Section divider** — reset attention between major arguments.
3. **Agenda / overview** — frame the questions and route through the deck.
4. **Text + image** — explain one visual and cite its source.
5. **Two columns** — compare options using the same criteria.
6. **Key findings** — communicate the three messages to retain.
7. **Metrics** — show a small set of figures with units, period and interpretation.
8. **Chart analysis** — use the editable chart, explain the takeaway and cite the data.
9. **Quote** — use only verified wording with clear attribution.
10. **Table** — keep headings short, align units and provide notes.
11. **Roadmap** — show stages, dependencies and decision points.
12. **Case study** — separate challenge, intervention and measurable outcome.
13. **Image-led statement** — one strong image and one clear message.
14. **Closing** — make the requested action and contact route unmistakable.
15. **References** — list sources, methods, caveats and access dates.

## Typography
- Space Grotesk: titles, section headers, display statements and labels.
- Inter: body text, descriptions, table content and captions.
- JetBrains Mono: slide numbers, dates, source metadata and small technical labels.
- Suggested sizes in this file are starting points. For dense content, split the slide rather than shrinking text excessively.
- Fonts are named in the presentation but are not embedded. Install the fonts on systems used to edit or present the deck, or check substituted typography before delivery.

## Colour
- Use `#0B0F1A` as the main background and `#0F1520` for occasional alternate sections.
- Use `#EDEAE3` for primary text and `#9AA4B8` for supporting text.
- Use `#00C2A8` as the primary accent. Amber, violet, coral, green and sky blue are secondary semantic accents.
- Do not encode meaning by colour alone. Add labels, values, icons or text.
- Check contrast after editing, especially small text and subtle lines.

## Charts, tables and evidence
- Prefer editable PowerPoint charts, tables and shapes.
- Label axes, units, dates and baselines. Add source and access date.
- The sample chart and KPI figures are placeholders only. Replace them before presenting.
- Separate measured results from interpretation and recommendations.
- Do not use a chart if a clear sentence or small table communicates the point better.

## Images
- Use original, licensed or otherwise authorised imagery.
- Crop consistently and add a concise caption plus creator/source credit.
- Avoid decorative imagery that does not add explanatory value.
- The included orbital shapes are editable placeholders and can be replaced or removed.

## Reuse and editing
- Duplicate the closest example slide, then replace its text and shapes.
- Use the built-in PowerPoint Arrange / Selection Pane to select overlapping vector motifs.
- Keep title and footer positions consistent. The footer includes a slide number and template label; edit `build_template.py` to change the defaults globally.
- Confidentiality labels are not enabled by default; add one only when required by the content.
