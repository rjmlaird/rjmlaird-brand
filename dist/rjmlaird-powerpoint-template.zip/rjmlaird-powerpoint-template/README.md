# rjmlaird.co.uk PowerPoint template

An editable 15-slide PowerPoint starter deck derived from the uploaded `global.css`.

## Files
- `rjmlaird-presentation-template.pptx` — editable widescreen PowerPoint example deck.
- `brand-design-tokens.md` — CSS token extraction and PowerPoint mappings.
- `template-guide.md` — layout and usage guidance.
- `build_template.py` — reproducible Python source.
- `README.md` — this file.

## Requirements
- Python 3.9+
- `python-pptx` (`pip install python-pptx`)
- Optional: LibreOffice for PDF rendering and visual inspection.

## Build
From this directory:

```bash
python -m pip install python-pptx
python build_template.py
```

The script writes `rjmlaird-presentation-template.pptx` to the current directory.

## Implementation notes
- The deck contains 15 editable example slides, not 15 custom PowerPoint slide-master layouts. The slides act as a documented master-slide system: duplicate the closest slide and replace its content.
- Native PowerPoint shapes, text boxes, a table and a line chart are used where practical. The chart is editable in PowerPoint.
- Fonts are referenced by name but not embedded; install Space Grotesk, Inter and JetBrains Mono for closest fidelity.
- Sample metrics and chart values are illustrative placeholders and must be replaced with sourced data.
- Validation is structural. Rendering depends on a compatible local office suite; do not assume visual inspection occurred unless a PDF or slide-image render was produced and checked.
