#!/usr/bin/env python3
"""Build an editable rjmlaird.co.uk PowerPoint template from the token mapping."""
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
from pptx.chart.data import CategoryChartData
from pathlib import Path
import argparse

# Source-derived palette. See brand-design-tokens.md for the token mapping.
C = {"ink":"0B0F1A","ink2":"0F1520","card":"141B29","lift":"1A2236","white":"EDEAE3",
     "muted":"9AA4B8","subtle":"8A98B2","teal":"00C2A8","amber":"F5A623","violet":"A78BFA",
     "coral":"FF8080","green":"4ADE80","sky":"38BDF8","focus":"7FE6D4","line":"303846"}
DISPLAY, BODY, MONO = "Space Grotesk", "Inter", "JetBrains Mono"
def rgb(v): return RGBColor.from_string(v)
def bg(s,c):
    s.background.fill.solid(); s.background.fill.fore_color.rgb=rgb(c)
def shape(s,k,x,y,w,h,fill=None,stroke=None):
    z=s.shapes.add_shape(k, Inches(x), Inches(y), Inches(w), Inches(h))
    if fill: z.fill.solid(); z.fill.fore_color.rgb=rgb(fill)
    else: z.fill.background()
    if stroke: z.line.color.rgb=rgb(stroke); z.line.width=Pt(.8)
    else: z.line.fill.background()
    return z
def txt(s,t,x,y,w,h,size=16,color=None,font=BODY,bold=False,align=PP_ALIGN.LEFT):
    b=s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h)); f=b.text_frame
    f.clear(); f.word_wrap=True; f.margin_left=f.margin_right=f.margin_top=f.margin_bottom=0
    p=f.paragraphs[0]; p.alignment=align; p.space_after=Pt(0); r=p.add_run(); r.text=str(t)
    r.font.name=font; r.font.size=Pt(size); r.font.bold=bold; r.font.color.rgb=rgb(color or C["white"])
    return b
def ln(s,x1,y1,x2,y2,c=None,w=1):
    z=s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x1), Inches(y1), Inches(x2), Inches(y2))
    z.line.color.rgb=rgb(c or C["line"]); z.line.width=Pt(w)
def head(s,label,title,sub=None):
    txt(s,label.upper(),.72,.46,11.8,.25,9,C["teal"],DISPLAY,True)
    txt(s,title,.72,.88,11.9,.62,30,C["white"],DISPLAY,True)
    if sub: txt(s,sub,.72,1.58,11.9,.42,13,C["muted"])
def foot(s,n):
    ln(s,.72,7.08,12.62,7.08)
    txt(s,"rjmlaird.co.uk  /  EDITABLE TEMPLATE",.74,7.16,8.7,.16,7.5,C["subtle"],MONO)
    txt(s,f"{n:02d}",11.9,7.13,.7,.2,9,C["teal"],MONO,True,PP_ALIGN.RIGHT)
def start(p,c=None):
    s=p.slides.add_slide(p.slide_layouts[6]); bg(s,c or C["ink"]); return s
def bullet(s,t,x,y,w,c=C["teal"]):
    shape(s,MSO_SHAPE.OVAL,x,y+.12,.08,.08,c); txt(s,t,x+.22,y,w-.22,.5,13,C["white"])
def build(out):
    p=Presentation(); p.slide_width=Inches(13.333); p.slide_height=Inches(7.5)
    p.core_properties.title="rjmlaird.co.uk — Editable PowerPoint Template"
    p.core_properties.author="rjmlaird.co.uk"
    # 1 Title
    s=start(p)
    for w,h,col in [(4.4,4.4,C["teal"]),(3.2,3.2,C["violet"]),(2,2,C["amber"])]:
        shape(s,MSO_SHAPE.OVAL,8.35+(4.4-w)/2,1.15+(4.4-h)/2,w,h,None,col)
    txt(s,"rjmlaird.co.uk  /  PRESENTATION SYSTEM",.72,.78,7,.25,9,C["teal"],DISPLAY,True)
    txt(s,"Presentation\\nTitle Goes Here",.72,1.65,7.4,1.75,36,C["white"],DISPLAY,True)
    txt(s,"A clear, evidence-led subtitle that explains the central question.",.76,3.72,6.4,.8,18,C["muted"])
    ln(s,.76,5,3.4,5,C["teal"],2)
    txt(s,"Presenter Name  ·  Organisation",.76,5.28,6.5,.32,12,C["white"],BODY,True)
    txt(s,"12 OCTOBER 2026  /  VERSION 1.0",.76,5.7,6.5,.3,9,C["amber"],MONO,True)
    # The primary deliverable is a deck of 15 editable exemplar layouts. For brevity,
    # subsequent slides are created from compact reusable patterns below.
    specs=[
      ("SECTION 01 / CONTEXT","Start with the question that matters.","One short framing statement. Explain why this section exists.", "01"),
      ("OVERVIEW","Today’s route through the evidence","Context · Evidence · Implications · Next steps",""),
      ("EDITORIAL LAYOUT","A visual that earns its place","Image placeholder + caption + editorial explanation",""),
      ("COMPARISON","Two perspectives, one decision","Option A versus Option B, using matched criteria",""),
      ("KEY FINDINGS","Three messages to remember","Signal · Consequence · Action",""),
      ("METRICS","Numbers need interpretation","Illustrative KPI placeholders with units and period",""),
      ("CHART-LED ANALYSIS","Show the pattern, then explain it","Editable chart area, takeaway and source note",""),
      ("PULL QUOTE","A short, memorable quotation","Verified quotation · Attribution · Source",""),
      ("TABLE / COMPARISON","Make the comparison easy to scan","Editable table with criteria, options and notes",""),
      ("PROCESS / ROADMAP","A sequence with clear decision points","Frame · Test · Decide · Learn",""),
      ("CASE STUDY","From challenge to evidenced outcome","Challenge · Intervention · Outcome",""),
      ("IMAGE-LED STATEMENT","One idea. Clearly stated.","Large visual placeholder with a concise message",""),
      ("CLOSING / NEXT STEPS","Make the next step unmistakable.","Call to action and contact details",""),
      ("REFERENCES / SOURCES","Make every important claim traceable","Citations, methods, caveats and access dates","")
    ]
    for i,(lab,ttl,sub,num) in enumerate(specs,2):
        s=start(p,C["ink2"] if i in (2,9,13) else C["ink"])
        head(s,lab,ttl,sub)
        if i==2:
            for j,(h,d) in enumerate([("The context","What has changed, and why now?"),("The evidence","What do the sources show?"),("The implications","What follows from the findings?"),("The next steps","What should happen next?")]):
                y=2.1+j*.9; txt(s,f"{j+1:02d}",.82,y,.6,.3,12,C["teal"],MONO,True); txt(s,h,1.6,y,3,.35,17,C["white"],DISPLAY,True); txt(s,d,4.6,y,6.5,.35,13,C["muted"]); ln(s,.82,y+.58,12.4,y+.58)
        elif i==3:
            shape(s,MSO_SHAPE.RECTANGLE,.8,2.1,6.2,3.7,C["card"],C["line"]); txt(s,"IMAGE PLACEHOLDER",1.1,3.5,5.5,.4,14,C["amber"],MONO,True,PP_ALIGN.CENTER)
            txt(s,"Caption and image credit",.85,5.95,6,.3,10,C["muted"]); txt(s,"The story behind the image",7.5,2.2,4.6,.5,22,C["white"],DISPLAY,True)
            bullet(s,"Explain what the audience should notice.",7.55,3.0,4.2); bullet(s,"Connect the visual to a sourced claim.",7.55,3.7,4.2); bullet(s,"Add context, not decorative copy.",7.55,4.4,4.2)
        elif i==4:
            for j,(lab2,h) in enumerate([("OPTION A","Build on what works"),("OPTION B","Change the operating model")]):
                x=.82+j*6.05; shape(s,MSO_SHAPE.RECTANGLE,x,2.2,5.6,3.5,C["card"],C["line"]); txt(s,lab2,x+.25,2.5,3,.25,9,C["teal"] if j==0 else C["violet"],DISPLAY,True); txt(s,h,x+.25,3.0,4.9,.5,20,C["white"],DISPLAY,True)
                bullet(s,"Strength, trade-off and best-use case",x+.25,3.9,4.8,C["teal"] if j==0 else C["violet"])
                bullet(s,"Use the same criteria on both sides",x+.25,4.6,4.8,C["teal"] if j==0 else C["violet"])
        elif i==6:
            for j,(a,b) in enumerate([("01","The signal"),("02","The consequence"),("03","The action")]):
                x=.82+j*4.05; shape(s,MSO_SHAPE.RECTANGLE,x,2.4,3.6,2.8,C["card"],C["line"]); txt(s,a,x+.25,2.7,.7,.3,14,[C["teal"],C["amber"],C["violet"]][j],MONO,True); txt(s,b,x+.25,3.35,3,.4,19,C["white"],DISPLAY,True); txt(s,"Replace with a concise, evidenced finding.",x+.25,4.0,3,.75,12,C["muted"])
        elif i==7:
            for j,(v,l) in enumerate([("00.0%","Primary metric"),("000","Supporting count"),("±0.0","Change over time")]):
                x=.82+j*4.05; shape(s,MSO_SHAPE.RECTANGLE,x,2.3,3.6,1.7,C["card"],C["line"]); txt(s,v,x+.25,2.65,3,.55,28,[C["teal"],C["amber"],C["violet"]][j],MONO,True); txt(s,l,x+.25,3.35,3,.3,13,C["white"],DISPLAY,True)
            shape(s,MSO_SHAPE.RECTANGLE,.82,4.55,11.6,.9,C["ink2"],C["teal"]); txt(s,"INTERPRETATION: what changed, against which baseline, and why does it matter?",1.05,4.85,10.9,.3,14,C["white"])
        elif i==8:
            shape(s,MSO_SHAPE.RECTANGLE,.82,2.1,7.0,3.6,C["card"],C["line"]); txt(s,"EDITABLE CHART AREA",1.1,3.5,6.4,.4,16,C["teal"],MONO,True,PP_ALIGN.CENTER)
            txt(s,"TAKEAWAY",8.2,2.3,3,.25,9,C["teal"],MONO,True); txt(s,"Describe the change, not just the line.",8.2,2.8,3.8,1,20,C["white"],DISPLAY,True); txt(s,"Source: [dataset / URL], accessed [date].",.85,6.1,10,.25,9,C["subtle"],MONO)
        elif i==10:
            for j,(h,d) in enumerate([("01  Frame","Question + scope"),("02  Test","Evidence + options"),("03  Decide","Trade-offs + owner"),("04  Learn","Measure + adapt")]):
                x=.8+j*3.05; shape(s,MSO_SHAPE.OVAL,x+.3,2.6,.65,.65,[C["teal"],C["sky"],C["amber"],C["violet"]][j]); txt(s,h,x,3.55,2.6,.35,17,C["white"],DISPLAY,True); txt(s,d,x,4.1,2.6,.4,12,C["muted"])
                if j<3: ln(s,x+1,2.93,x+3,2.93)
        elif i==11:
            for j,(h,d) in enumerate([("CHALLENGE","What needed to change?"),("INTERVENTION","What was done, and why?"),("OUTCOME","What changed measurably?")]):
                x=.82+j*4.05; shape(s,MSO_SHAPE.RECTANGLE,x,2.2,3.6,2.8,C["card"],C["line"]); txt(s,h,x+.25,2.5,3,.3,10,[C["teal"],C["amber"],C["green"]][j],DISPLAY,True); txt(s,d,x+.25,3.15,3,.65,17,C["white"],DISPLAY,True); txt(s,"Evidence: [metric / source]",x+.25,4.2,3,.3,10,C["muted"])
        elif i==12:
            shape(s,MSO_SHAPE.RECTANGLE,.82,2.0,7.0,3.8,C["card"],C["line"]); txt(s,"IMAGE / ARTWORK PLACEHOLDER",1.1,3.6,6.4,.4,13,C["amber"],MONO,True,PP_ALIGN.CENTER); txt(s,"One idea.\\nClearly stated.",8.3,2.4,3.8,1.2,27,C["white"],DISPLAY,True); txt(s,"One supporting sentence.",8.3,4,3.8,.6,14,C["muted"])
        elif i==13:
            txt(s,"Make the next step unmistakable.",.82,1.9,7.0,1.2,32,C["white"],DISPLAY,True); shape(s,MSO_SHAPE.RECTANGLE,.82,4.0,5.2,.8,C["teal"]); txt(s,"CALL TO ACTION  →",1.1,4.25,4.5,.3,13,C["ink"],DISPLAY,True)
            txt(s,"EMAIL  name@example.com\\nWEB  rjmlaird.co.uk\\nLINKEDIN  [profile URL]",8.2,2.3,4,.95,12,C["white"])
        elif i==14:
            for j,t in enumerate(["Author / organisation (Year). Title. Publisher. URL or DOI.","Dataset (version/date). Provider. URL. Accessed YYYY-MM-DD.","Interview / communication, role, date and permission status.","Method note: scope, assumptions, exclusions and limitations."]):
                y=2.1+j*.75; txt(s,f"[{j+1:02d}]",.85,y,.7,.3,11,C["teal"],MONO,True); txt(s,t,1.7,y,10.5,.4,12,C["white"])
        else:
            txt(s,"Insert a verified quotation here.",1.1,2.2,10.2,1.2,27,C["white"],DISPLAY,True); txt(s,"NAME / ROLE · SOURCE · DATE",1.2,4.3,8,.3,11,C["muted"],MONO)
        foot(s,i)
    # Add native editable table on the table layout.
    s=p.slides[9]
    t=s.shapes.add_table(4,4, Inches(.82), Inches(2.35), Inches(11.6), Inches(2.65)).table
    vals=[["CRITERION","OPTION A","OPTION B","EVIDENCE / NOTE"],["Cost","[value + unit]","[value + unit]","[source]"],["Time","[duration]","[duration]","[scope]"],["Impact","[outcome]","[outcome]","[indicator]"]]
    for r,row in enumerate(vals):
        for c,v in enumerate(row):
            ce=t.cell(r,c); ce.text=v; ce.fill.solid(); ce.fill.fore_color.rgb=rgb(C["lift"] if r==0 else C["card"])
            for pp in ce.text_frame.paragraphs:
                pp.font.name=DISPLAY if r==0 else BODY; pp.font.size=Pt(9 if r==0 else 10); pp.font.bold=(r==0 or c==0); pp.font.color.rgb=rgb(C["teal"] if r==0 else C["white"])
    p.save(out)
if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--output",default="rjmlaird-presentation-template.pptx"); args=ap.parse_args(); build(Path(args.output))
